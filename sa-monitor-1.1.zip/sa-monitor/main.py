import configparser
import json
import time
import sys
import psutil
import resend
import urllib.request
from pymem import Pymem
from pymem.process import module_from_name

EXP_ADDR = 0x0462BEB8
STONE_COIN_ADDR = 0x0462BEE8
LEVEL_ADDR = 0x422BEC0
CLOTHING_DURABILITY_ADDR = 0x422C239
NICKNAME_OFFSET = 0x421BA5C
NICKNAME_BYTE_LEN = 16
COORD_EAST_ADDR = 0x004BB414
COORD_SOUTH_ADDR = 0x004BB418
MAP_ID_ADDR = 0x04581190
TEAMMATE1_NICKNAME_ADDR = 0x04630908
TEAMMATE1_NICKNAME_BYTE_LEN = 16
TEAMMATE2_EXIST_ADDR = 0x04630920
TEAMMATE3_EXIST_ADDR = 0x04630950
TEAMMATE4_EXIST_ADDR = 0x04630980
TEAMMATE5_EXIST_ADDR = 0x046309B0
LEADER_WEBHOOK_URL = "http://47.105.42.104:25678/webhook/sa40s"
LEADER_REPORT_INTERVAL_CYCLES = 2
DEFAULT_VERSION = "v1.1"


def load_config(config_path: str = "config.ini"):
    parser = configparser.ConfigParser()
    parser.read(config_path, encoding="utf-8")
    app_cfg = parser["app"]
    return {
        "version": app_cfg.get("version", DEFAULT_VERSION),
        "sa_program_id": app_cfg.get("sa_program_id", "sa_9061.exe"),
        "user_email": app_cfg.get("user_email", ""),
        "resend_api_key": app_cfg.get("resend_api_key", ""),
        "check_interval_seconds": app_cfg.getint("check_interval_seconds", 30),
        "monitor_player_alias_list": json.loads(app_cfg.get("monitor_player_alias_list", "[]")),
        "min_clothing_durability": app_cfg.getint("min_clothing_durability", 50),
        "leader_mode": app_cfg.getboolean("leader_mode", False),
        "debug": app_cfg.getboolean("debug", False),
    }


def read_uint4(pm: Pymem, address: int):
    return pm.read_uint(address)


def read_bytes(pm: Pymem, address: int, length: int):
    return pm.read_bytes(address, length)


def read_byte(pm: Pymem, address: int):
    raw = pm.read_bytes(address, 1)
    return raw[0] if raw else 0


def scan_game_processes(program_id: str, alias_list: list):
    results = []
    program_lower = program_id.lower()
    for proc in psutil.process_iter():
        try:
            if proc.name().lower() != program_lower:
                continue
            pid = proc.pid
            pm = Pymem(pid)
            mod = module_from_name(pm.process_handle, program_id)
            mod_base = mod.lpBaseOfDll
            abs_nick_addr = mod_base + NICKNAME_OFFSET
            abs_level_addr = mod_base + LEVEL_ADDR
            abs_durability_addr = mod_base + CLOTHING_DURABILITY_ADDR

            exp = read_uint4(pm, EXP_ADDR)
            stone_coin = read_uint4(pm, STONE_COIN_ADDR)
            level = read_uint4(pm, abs_level_addr)
            raw_bytes = read_bytes(pm, abs_nick_addr, NICKNAME_BYTE_LEN)
            nickname = raw_bytes.decode("gbk", errors="replace").split("\x00")[0].strip()

            clothing_durability_raw = read_bytes(pm, abs_durability_addr, 16)
            clothing_durability_str = clothing_durability_raw.decode("gbk", errors="replace").split("\x00")[0].strip()
            digits = []
            for ch in clothing_durability_str:
                if ch.isdigit():
                    digits.append(ch)
                elif ch == '%':
                    break
            clothing_durability_value = int(''.join(digits)) if digits else 0
            if clothing_durability_value > 0 and '%' not in clothing_durability_str:
                clothing_durability_str = f"{clothing_durability_value}%"

            coord_east = read_uint4(pm, COORD_EAST_ADDR)
            coord_south = read_uint4(pm, COORD_SOUTH_ADDR)
            map_id = read_uint4(pm, MAP_ID_ADDR)
            teammate1_raw = read_bytes(pm, TEAMMATE1_NICKNAME_ADDR, TEAMMATE1_NICKNAME_BYTE_LEN)
            teammate1_nickname = teammate1_raw.decode("gbk", errors="replace").split("\x00")[0].strip()

            tm2_exist = 1 if read_byte(pm, TEAMMATE2_EXIST_ADDR) > 0 else 0
            tm3_exist = 1 if read_byte(pm, TEAMMATE3_EXIST_ADDR) > 0 else 0
            tm4_exist = 1 if read_byte(pm, TEAMMATE4_EXIST_ADDR) > 0 else 0
            tm5_exist = 1 if read_byte(pm, TEAMMATE5_EXIST_ADDR) > 0 else 0
            player_count = 1 + tm2_exist + tm3_exist + tm4_exist + tm5_exist

            if nickname and nickname in alias_list:
                results.append({
                    "pid": pid,
                    "nickname": nickname,
                    "exp": exp,
                    "stone_coin": stone_coin,
                    "level": level,
                    "clothing_durability": clothing_durability_value,
                    "clothing_durability_str": clothing_durability_str if clothing_durability_str else f"{clothing_durability_value}%",
                    "coord_east": coord_east,
                    "coord_south": coord_south,
                    "map_id": map_id,
                    "teammate1_nickname": teammate1_nickname,
                    "teammate2_exist": tm2_exist,
                    "teammate3_exist": tm3_exist,
                    "teammate4_exist": tm4_exist,
                    "teammate5_exist": tm5_exist,
                    "player_count": player_count,
                })
        except Exception:
            continue
    return results


def send_stagnant_email(api_key: str, to_email: str, nickname: str, level: int, prev_exp: int, curr_exp: int):
    resend.api_key = api_key
    subject = f"【石器时代监控】玩家 {nickname} 经验未增加提醒"
    html = f"""
    <div style="font-family: 'Microsoft YaHei', Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 24px; border-radius: 8px 8px 0 0;">
            <h2 style="color: #ffffff; margin: 0; text-align: center;">石器时代监控告警</h2>
        </div>
        <div style="background: #f8f9fa; padding: 24px; border-radius: 0 0 8px 8px; border: 1px solid #e9ecef;">
            <div style="background: #fff3cd; border-left: 4px solid #ffc107; padding: 16px; margin-bottom: 20px; border-radius: 4px;">
                <strong style="color: #856404;">⚠️ 经验停滞检测</strong>
            </div>
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
                <tr>
                    <td style="padding: 10px; border-bottom: 1px solid #dee2e6; font-weight: bold; color: #495057; width: 40%;">玩家昵称</td>
                    <td style="padding: 10px; border-bottom: 1px solid #dee2e6; color: #212529;">{nickname}</td>
                </tr>
                <tr>
                    <td style="padding: 10px; border-bottom: 1px solid #dee2e6; font-weight: bold; color: #495057;">人物等级</td>
                    <td style="padding: 10px; border-bottom: 1px solid #dee2e6; color: #212529;">Lv.{level}</td>
                </tr>
                <tr>
                    <td style="padding: 10px; border-bottom: 1px solid #dee2e6; font-weight: bold; color: #495057;">上次经验值</td>
                    <td style="padding: 10px; border-bottom: 1px solid #dee2e6; color: #212529;">{prev_exp}</td>
                </tr>
                <tr>
                    <td style="padding: 10px; border-bottom: 1px solid #dee2e6; font-weight: bold; color: #495057;">当前经验值</td>
                    <td style="padding: 10px; border-bottom: 1px solid #dee2e6; color: #212529;">{curr_exp}</td>
                </tr>
            </table>
            <div style="background: #dc3545; color: white; padding: 16px; border-radius: 4px; text-align: center;">
                <p style="margin: 0; font-size: 16px;">玩家可能已<strong>脱离队伍</strong>或<strong>断线</strong>，请及时检查！</p>
            </div>
            <p style="color: #6c757d; font-size: 12px; text-align: center; margin-top: 20px;">
                此邮件由 Stone Age Monitor 自动发送，发送后监控程序将自动退出。<br>
                请在排除问题后重新启动 startup.bat 以恢复监控。
            </p>
        </div>
    </div>
    """
    resend.Emails.send({
        "from": "onboarding@resend.dev",
        "to": to_email,
        "subject": subject,
        "html": html,
    })


def send_durability_email(api_key: str, to_email: str, nickname: str, level: int, durability: int, min_durability: int):
    resend.api_key = api_key
    subject = f"【石器时代监控】玩家 {nickname} 衣服耐久度过低提醒"
    html = f"""
    <div style="font-family: 'Microsoft YaHei', Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); padding: 24px; border-radius: 8px 8px 0 0;">
            <h2 style="color: #ffffff; margin: 0; text-align: center;">石器时代监控告警</h2>
        </div>
        <div style="background: #f8f9fa; padding: 24px; border-radius: 0 0 8px 8px; border: 1px solid #e9ecef;">
            <div style="background: #ffebee; border-left: 4px solid #ef5350; padding: 16px; margin-bottom: 20px; border-radius: 4px;">
                <strong style="color: #c62828;">⚠️ 衣服耐久度过低</strong>
            </div>
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
                <tr>
                    <td style="padding: 10px; border-bottom: 1px solid #dee2e6; font-weight: bold; color: #495057; width: 40%;">玩家昵称</td>
                    <td style="padding: 10px; border-bottom: 1px solid #dee2e6; color: #212529;">{nickname}</td>
                </tr>
                <tr>
                    <td style="padding: 10px; border-bottom: 1px solid #dee2e6; font-weight: bold; color: #495057;">人物等级</td>
                    <td style="padding: 10px; border-bottom: 1px solid #dee2e6; color: #212529;">Lv.{level}</td>
                </tr>
                <tr>
                    <td style="padding: 10px; border-bottom: 1px solid #dee2e6; font-weight: bold; color: #495057;">当前衣服耐久度</td>
                    <td style="padding: 10px; border-bottom: 1px solid #dee2e6; color: #dc3545; font-weight: bold;">{durability}%</td>
                </tr>
                <tr>
                    <td style="padding: 10px; border-bottom: 1px solid #dee2e6; font-weight: bold; color: #495057;">告警阈值</td>
                    <td style="padding: 10px; border-bottom: 1px solid #dee2e6; color: #212529;">&lt; {min_durability}%</td>
                </tr>
            </table>
            <div style="background: #dc3545; color: white; padding: 16px; border-radius: 4px; text-align: center;">
                <p style="margin: 0; font-size: 16px;">衣服耐久度已低于阈值，请及时<strong>修理装备</strong>！</p>
            </div>
            <p style="color: #6c757d; font-size: 12px; text-align: center; margin-top: 20px;">
                此邮件由 Stone Age Monitor 自动发送，发送后监控程序将自动退出。<br>
                请在修理装备后重新启动 startup.bat 以恢复监控。
            </p>
        </div>
    </div>
    """
    resend.Emails.send({
        "from": "onboarding@resend.dev",
        "to": to_email,
        "subject": subject,
        "html": html,
    })


def report_leader_info(player_list: list, version: str = DEFAULT_VERSION):
    reported = []
    for p in player_list:
        nickname = p["nickname"]
        player1 = p["teammate1_nickname"]
        if nickname and player1 and nickname == player1:
            pc = p.get("player_count", 1)
            payload = {
                "nickName": nickname,
                "mapId": p["map_id"],
                "east": p["coord_east"],
                "south": p["coord_south"],
                "player1": player1,
                "playerCount": pc,
                "version": version,
            }
            try:
                data = json.dumps(payload).encode("utf-8")
                req = urllib.request.Request(
                    LEADER_WEBHOOK_URL,
                    data=data,
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                with urllib.request.urlopen(req, timeout=8) as resp:
                    body = resp.read().decode("utf-8", errors="replace")
                    reported.append((nickname, resp.status, body, pc))
            except Exception as e:
                reported.append((nickname, None, str(e), pc))
    return reported


def main():
    try:
        cfg = load_config()
    except Exception as e:
        print(f"[错误] 读取配置文件失败: {e}")
        sys.exit(1)

    program_id = cfg["sa_program_id"]
    alias_list = cfg["monitor_player_alias_list"]
    interval = cfg["check_interval_seconds"]
    user_email = cfg["user_email"]
    resend_api_key = cfg["resend_api_key"]
    min_clothing_durability = cfg["min_clothing_durability"]
    leader_mode = cfg["leader_mode"]
    debug_mode = cfg["debug"]
    app_version = cfg["version"]

    if not alias_list:
        print("[错误] monitor_player_alias_list 为空，请在 config.ini 中配置需要监控的玩家昵称")
        sys.exit(1)

    print("=" * 50)
    print(f"  Stone Age Monitor ({app_version}) 已启动")
    print("=" * 50)
    print(f"  目标程序:         {program_id}")
    print(f"  检查间隔:         {interval} 秒")
    print(f"  通知邮箱:         {user_email}")
    print(f"  最低衣服耐久度:   < {min_clothing_durability}%")
    print(f"  队长上报模式:     {'开启 (每 ' + str(LEADER_REPORT_INTERVAL_CYCLES) + ' 轮上报一次)' if leader_mode else '关闭'}")
    print(f"  Debug 模式:       {'开启' if debug_mode else '关闭'}")
    print(f"  监控玩家数:       {len(alias_list)} 人")
    for alias in alias_list:
        print(f"    - {alias}")
    print("=" * 50)
    print()

    last_exp_map = {}
    allow_notify_map = {}
    last_notified_exp_map = {}
    anomaly_map = {}
    cycle_count = 0
    MIN_EXP_RECOVERY_GAIN = 3000

    while True:
        cycle_count += 1
        cycle_time = time.strftime("%Y-%m-%d %H:%M:%S")
        print(f"--- 第 {cycle_count} 次检查 | {cycle_time} ---")

        found_players = scan_game_processes(program_id, alias_list)

        if not found_players:
            print("  [提示] 未找到匹配的玩家进程，继续等待...")
        else:
            for p in found_players:
                nickname = p["nickname"]
                exp = p["exp"]
                stone_coin = p["stone_coin"]
                level = p["level"]
                clothing_durability = p["clothing_durability"]
                clothing_durability_str = p["clothing_durability_str"]

                if nickname not in allow_notify_map:
                    allow_notify_map[nickname] = True
                if nickname not in anomaly_map:
                    anomaly_map[nickname] = "正常"

                is_durability_low = clothing_durability > 0 and clothing_durability < min_clothing_durability
                prev_exp = last_exp_map.get(nickname)
                is_stagnant = prev_exp is not None and prev_exp == exp

                baseline_exp = last_notified_exp_map.get(nickname, prev_exp if prev_exp is not None else exp)
                if not allow_notify_map[nickname]:
                    exp_recovered_ok = (prev_exp is not None) and ((exp - baseline_exp) >= MIN_EXP_RECOVERY_GAIN)
                    dur_recovered_ok = clothing_durability > 0 and (not is_durability_low)
                    if exp_recovered_ok and dur_recovered_ok:
                        allow_notify_map[nickname] = True
                        anomaly_map[nickname] = "正常"
                        print(f"  [恢复] 玩家 {nickname} 已恢复正常（经验提升 {exp - baseline_exp} + 衣服耐久 {clothing_durability_str}），允许重新通知")

                if is_durability_low:
                    anomaly_map[nickname] = "衣服损坏"
                    if allow_notify_map[nickname]:
                        print(f"  [警告] 玩家 {nickname} 衣服耐久度过低！当前: {clothing_durability_str} 阈值: < {min_clothing_durability}%")
                        print()
                        print("=" * 50)
                        print(f"  检测到衣服耐久度过低，准备发送邮件通知: {nickname}")
                        try:
                            send_durability_email(resend_api_key, user_email, nickname, level, clothing_durability, min_clothing_durability)
                            print("  邮件发送成功！")
                        except Exception as e:
                            print(f"  [错误] 邮件发送失败: {e}")
                        allow_notify_map[nickname] = False
                        print(f"  该玩家通知已暂停，待经验增长 >= {MIN_EXP_RECOVERY_GAIN} 且 衣服耐久 >= {min_clothing_durability}% 后自动重置...")
                        print("=" * 50)
                    else:
                        print(f"  [抑制] 玩家 {nickname} 衣服耐久度过低 (当前: {clothing_durability_str})，已发送过邮件，本次不再重复通知")

                if is_stagnant:
                    if anomaly_map[nickname] == "正常":
                        anomaly_map[nickname] = "断线或离队"
                    if allow_notify_map[nickname]:
                        print(f"  [警告] 玩家 {nickname} 经验值未变化！上一轮: {prev_exp} 当前: {exp}")
                        print()
                        print("=" * 50)
                        print(f"  检测到经验停滞，准备发送邮件通知: {nickname}")
                        try:
                            send_stagnant_email(resend_api_key, user_email, nickname, level, prev_exp, exp)
                            print("  邮件发送成功！")
                        except Exception as e:
                            print(f"  [错误] 邮件发送失败: {e}")
                        allow_notify_map[nickname] = False
                        last_notified_exp_map[nickname] = exp
                        print(f"  该玩家通知已暂停，待经验增长 >= {MIN_EXP_RECOVERY_GAIN} 且 衣服耐久 >= {min_clothing_durability}% 后自动重置...")
                        print("=" * 50)
                    else:
                        print(f"  [抑制] 玩家 {nickname} 经验停滞 (当前: {exp})，已发送过邮件，本次不再重复通知")

                last_exp_map[nickname] = exp
                if allow_notify_map[nickname]:
                    notify_txt = "允许通知"
                else:
                    notify_txt = "通知暂停"
                print(f"  [PID {p['pid']}] 昵称: {nickname} | 等级: Lv.{level} | 石币: {stone_coin} | 经验: {exp} | 衣服耐久: {clothing_durability_str} | {notify_txt} | {anomaly_map[nickname]}")
                if debug_mode:
                    coord_east = p["coord_east"]
                    coord_south = p["coord_south"]
                    map_id = p["map_id"]
                    teammate1 = p["teammate1_nickname"] if p["teammate1_nickname"] else "(无)"
                    player_cnt = p["player_count"]
                    tm2 = "✓" if p["teammate2_exist"] else "✗"
                    tm3 = "✓" if p["teammate3_exist"] else "✗"
                    tm4 = "✓" if p["teammate4_exist"] else "✗"
                    tm5 = "✓" if p["teammate5_exist"] else "✗"
                    print(f"         [DEBUG] 坐标-东: {coord_east} | 坐标-南: {coord_south} | 地图编号: {map_id} | 队员1昵称: {teammate1}")
                    print(f"         [DEBUG] 队员总数: {player_cnt} 人 | 队员2: {tm2} | 队员3: {tm3} | 队员4: {tm4} | 队员5: {tm5}")

        if leader_mode and found_players and (cycle_count % LEADER_REPORT_INTERVAL_CYCLES == 0):
            if debug_mode:
                print(f"  [队长上报] 第 {cycle_count} 轮触发上报，正在检测队长身份...")
            reports = report_leader_info(found_players, app_version)
            if debug_mode:
                if not reports:
                    print("  [队长上报] 当前轮次未检测到队长身份，无需上报。")
                else:
                    for nickname, status, body, pc in reports:
                        if status is not None:
                            preview = body if len(body) <= 80 else body[:80] + "..."
                            print(f"  [队长上报] 玩家 {nickname} 上报成功 (HTTP {status}) 队员总数: {pc} 响应: {preview}")
                        else:
                            print(f"  [队长上报] 玩家 {nickname} 上报失败 队员总数: {pc} 原因: {body}")

        print()
        time.sleep(interval)


if __name__ == "__main__":
    main()
