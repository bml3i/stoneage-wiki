@echo off
chcp 65001 >nul
title Stone Age Monitor
cd /d "%~dp0"

echo.
echo ================================================
echo   Stone Age Monitor 启动中...
echo ================================================
echo.

where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [错误] 未检测到 Python，请先安装 Python 并添加到 PATH 环境变量
    pause
    exit /b 1
)

echo [1/2] 检查依赖...
pip show psutil >nul 2>nul
if %errorlevel% neq 0 (
    echo 正在安装 psutil...
    pip install psutil
)
pip show pymem >nul 2>nul
if %errorlevel% neq 0 (
    echo 正在安装 pymem...
    pip install pymem
)
pip show resend >nul 2>nul
if %errorlevel% neq 0 (
    echo 正在安装 resend...
    pip install resend
)

echo.
echo [2/2] 启动监控主程序...
echo.
python main.py

if %errorlevel% neq 0 (
    echo.
    echo [提示] 程序已退出，按任意键关闭窗口...
    pause >nul
)
